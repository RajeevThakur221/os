from sklearn.linear_model import LinearRegression

# Define mileage (input) and price (output)
mileage = [[10], [20], [30], [40], [50], [60], [70], [80]]
price = [24, 19, 17, 13, 10, 7, 5, 2]

# Create and train the linear regression model
reg = LinearRegression()
reg.fit(mileage, price)

# Print the model parameters
print('Intercept:', reg.intercept_)
print('Coefficient:', reg.coef_[0])

# Define new mileage values for prediction
new_mileage = [[25], [45], [65]]
predicted_price = reg.predict(new_mileage)

# Print predicted prices
print('Predicted prices:', predicted_price)
