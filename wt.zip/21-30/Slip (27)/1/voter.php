<?php
// Retrieve form data
$name = $_POST['name'];
$age = $_POST['age'];
$nationality = $_POST['nationality'];

// Validate name (should be uppercase letters only)
if (preg_match('/[^A-Z]/', $name)) {
    echo 'Name should be in uppercase letters only.';
} 
// Validate age (should be 18 or above)
elseif ($age < 18) {
    echo 'Age should not be less than 18 years.';
} 
// Validate nationality (should be "Indian")
elseif (strcasecmp($nationality, 'Indian') !== 0) {
    echo 'Nationality should be Indian.';
} 
// If all validations pass
else {
    echo 'Validation successful. <br>';
    echo 'Voter Details: <br>';
    echo 'Name: ' . $name . '<br>';
    echo 'Age: ' . $age . '<br>';
    echo 'Nationality: ' . $nationality;
}
?>
