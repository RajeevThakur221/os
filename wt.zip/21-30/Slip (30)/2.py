# Import necessary libraries
from mlxtend.frequent_patterns import apriori, association_rules

# Define transactions
transactions = [['eggs', 'milk', 'bread'],
               ['eggs', 'apple'],
               ['milk', 'bread'],
               ['apple', 'milk'],
               ['milk', 'apple', 'bread']]

# Create a dictionary to map items to unique numeric values
item_to_num = {'eggs': 1, 'milk': 2, 'bread': 3, 'apple': 4}

# Convert categorical values in the dataset to numeric values
numeric_transactions = []
for transaction in transactions:
    numeric_transaction = [item_to_num[item] for item in transaction]
    numeric_transactions.append(numeric_transaction)

print(numeric_transactions)

# Generate frequent itemsets with a minimum support of 0.4
frequent_itemsets = apriori(numeric_transactions, min_support=0.4, use_colnames=True)

# Generate association rules with a minimum confidence of 0.7
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.7)

print(frequent_itemsets)
print(rules)
