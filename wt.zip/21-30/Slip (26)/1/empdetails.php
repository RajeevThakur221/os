<?php
// Establish database connection
$conn = pg_connect("host=localhost dbname=database_name user=username password=password");

if (!$conn) {
    die("Connection failed: " . pg_last_error());
}

// Get the selected employee name from AJAX request
$employeeName = $_POST['employeeName'] ?? '';

if (!empty($employeeName)) {
    // Query the EMP table for the details of the selected employee
    $sql = "SELECT * FROM EMP WHERE ename = $1";
    $result = pg_query_params($conn, $sql, array($employeeName));

    if (pg_num_rows($result) > 0) {
        // Build a JSON object with employee details
        $employee = pg_fetch_assoc($result);
        $response = array(
            'ename' => $employee['ename'],
            'designation' => $employee['designation'],
            'salary' => $employee['salary']
        );
        echo json_encode($response);
    } else {
        echo json_encode(array('error' => 'Employee not found'));
    }
} else {
    echo json_encode(array('error' => 'Invalid request'));
}

// Close database connection
pg_close($conn);
?>
