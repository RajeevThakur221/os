import pandas as pd
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.tokenize import word_tokenize

# Read the dataset
df = pd.read_csv("covid_2021_1.csv")

# Remove null values and duplicates
df.dropna(inplace=True)
df.drop_duplicates(subset=["Comment"], inplace=True)

# Download necessary NLTK resources
nltk.download("punkt")
nltk.download("vader_lexicon")

# Initialize Sentiment Intensity Analyzer
sia = SentimentIntensityAnalyzer()

# Tokenize comments into words (optional, not used in analysis)
df["tokens"] = df["Comment"].apply(word_tokenize)

# Perform sentiment analysis
df["sentiment_score"] = df["Comment"].apply(lambda x: sia.polarity_scores(x)["compound"])

# Categorize comments into Positive, Negative, and Neutral
df["sentiment"] = df["sentiment_score"].apply(
    lambda score: "Positive" if score > 0 else ("Negative" if score < 0 else "Neutral")
)

# Calculate percentages
total_comments = len(df)
positive_comments = len(df[df["sentiment"] == "Positive"])
negative_comments = len(df[df["sentiment"] == "Negative"])
neutral_comments = len(df[df["sentiment"] == "Neutral"])

positive_percentage = (positive_comments / total_comments) * 100
negative_percentage = (negative_comments / total_comments) * 100
neutral_percentage = (neutral_comments / total_comments) * 100

# Print the results
print(f"Total Comments: {total_comments}")
print(f"Positive Comments: {positive_comments} ({positive_percentage:.2f}%)")
print(f"Negative Comments: {negative_comments} ({negative_percentage:.2f}%)")
print(f"Neutral Comments: {neutral_comments} ({neutral_percentage:.2f}%)")
