import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# 1. Load the dataset
data = pd.read_csv('user_data.csv')

# 2. Preprocess data (Remove NaN values)
data.dropna(inplace=True)

# Extracting features (X) and target variable (Y)
X = data[['age']].values  # Keeping it 2D
Y = data[['income']].values  # Keeping it 2D

# 3. Split data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# 4. Train the Linear Regression model
regressor = LinearRegression()
regressor.fit(X_train, y_train)

# 5. Predict values for test set
y_pred = regressor.predict(X_test)

# 6. Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("R-squared Score:", r2)

# 7. Visualize results
plt.scatter(X_test, y_test, color='gray', label='Actual Data')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Regression Line')
plt.xlabel("Age")
plt.ylabel("Income")
plt.title("Age vs Income Linear Regression")
plt.legend()
plt.show()
