<!--/var/www/html/Practical/codeigniter4-framework-96a1e60/app/Controllers/NumberController.php
 -->

 <?php

namespace App\Controllers;

use CodeIgniter\Controller;

class NumberController extends Controller
{
    public function index()
    {
        return view('number_check'); // Loads the view file
    }
}
