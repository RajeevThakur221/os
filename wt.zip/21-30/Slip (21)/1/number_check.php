<!--/var/www/html/Practical/codeigniter4-framework-96a1e60/app/Views/number_check.php
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Number Check</title>
    <script src="<?= base_url('js/numberCheck.js'); ?>"></script>
</head>
<body>

    <h1>Number Check</h1>
    <p>Enter a number to check:</p>
    <input type="number" id="num"/>
    <button onclick="checkNumber()">Check</button>

</body>
</html>
