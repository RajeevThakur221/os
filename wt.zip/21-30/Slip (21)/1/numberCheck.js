/*/var/www/html/Practical/codeigniter4-framework-96a1e60/public/js/numberCheck.js
*/

function checkNumber() {
    var num = document.getElementById("num").value;
    
    if (num > 0) {
        alert("The number is positive.");
    } else if (num < 0) {
        alert("The number is negative.");
    } else {
        alert("The number is zero.");
    }
}
