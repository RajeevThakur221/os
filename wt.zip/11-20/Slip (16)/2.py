import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from heapq import nlargest

# Download necessary NLTK resources (Run this only once)
nltk.download('punkt')
nltk.download('stopwords')

# Sample text paragraph
text = """Natural Language Processing (NLP) is a subfield of linguistics, information engineering, 
and artificial intelligence concerned with the interactions between computers and human languages, 
in particular, how to program computers to process and analyze large amounts of natural language data. 
Challenges in natural language processing frequently involve speech recognition, natural language understanding, 
and natural language generation. The history of natural language processing generally started in the 1950s, 
although work can be found from earlier periods."""

# Remove special characters and digits
text = re.sub(r'[^a-zA-Z\s]', '', text)

# Tokenize the text into sentences
sentences = sent_tokenize(text)

# Tokenize words and remove stopwords
stop_words = set(stopwords.words('english'))
words = [word.lower() for sentence in sentences for word in word_tokenize(sentence) if word.lower() not in stop_words]

# Calculate word frequency
word_freq = nltk.FreqDist(words)

# Calculate sentence scores based on word frequency
sentence_scores = {}
for sentence in sentences:
    for word in word_tokenize(sentence.lower()):
        if word in word_freq:
            if sentence not in sentence_scores:
                sentence_scores[sentence] = word_freq[word]
            else:
                sentence_scores[sentence] += word_freq[word]

# Generate summary by selecting top 3 sentences with highest scores
summary_sentences = nlargest(3, sentence_scores, key=sentence_scores.get)
summary = ' '.join(summary_sentences)

print("Summary:")
print(summary)
