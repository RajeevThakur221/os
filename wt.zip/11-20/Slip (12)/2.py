import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Create a random dataset with 10 samples
np.random.seed(42)  # Ensures reproducibility
heights = np.random.normal(170, 10, 10)
weights = np.random.normal(70, 5, 10)

# Combine the two arrays into a single dataset
dataset = pd.DataFrame({'Height': heights, 'Weight': weights})

# Split the dataset into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(dataset[['Height']], dataset['Weight'], test_size=0.2, random_state=42)

# Create a Linear Regression model and fit it to the training data
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Print the model coefficients
print('Model Coefficients:', lr_model.coef_)
print('Intercept:', lr_model.intercept_)

# Predict the weights for the test data and print results
y_pred = lr_model.predict(X_test)
print('\nPredictions:')
for actual, predicted in zip(y_test, y_pred):
    print(f'Actual: {actual:.2f}, Predicted: {predicted:.2f}')
