<?php
// Database connection details
$servername = "localhost";
$username = "root";  // Change to your DB username
$password = "";      // Change to your DB password
$dbname = "database_name";  // Change to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve selected teacher details
if (isset($_POST['tno'])) {
    $tno = mysqli_real_escape_string($conn, $_POST['tno']);
    
    $sql = "SELECT * FROM TEACHER WHERE tno = '$tno'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo "<strong>Teacher Name:</strong> " . $row['tname'] . "<br>";
        echo "<strong>Qualification:</strong> " . $row['qualification'] . "<br>";
        echo "<strong>Salary:</strong> $" . $row['salary'] . "<br>";
    } else {
        echo "No data found.";
    }
}

// Close database connection
mysqli_close($conn);
?>
