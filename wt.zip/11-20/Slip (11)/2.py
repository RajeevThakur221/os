import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# Creating the dataset
dataset = [
    ['butter', 'bread', 'milk'],
    ['butter', 'flour', 'milk', 'sugar'],
    ['butter', 'eggs', 'milk', 'salt'],
    ['eggs'],
    ['butter', 'flour', 'milk', 'salt']
]

# Converting the categorical values into numeric format
te = TransactionEncoder()
te_ary = te.fit_transform(dataset)
df = pd.DataFrame(te_ary, columns=te.columns_)

# Generating frequent itemsets using Apriori algorithm with different min_sup values
min_sup_values = [0.4, 0.3, 0.2]

for min_sup in min_sup_values:
    frequent_itemsets = apriori(df, min_support=min_sup, use_colnames=True)
    print(f"\nFrequent Itemsets with minimum support of {min_sup}:")
    print(frequent_itemsets)

    # Generating association rules
    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
    print(f"\nAssociation Rules with minimum confidence of 0.6 for min_sup {min_sup}:")
    print(rules)
