import pandas as pd
from textblob import TextBlob
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('movie_review.csv')

# Add a column for sentiment analysis using TextBlob
df['Sentiment'] = df['Review'].apply(lambda x: TextBlob(str(x)).sentiment.polarity)

# Create a new dataframe for positive reviews only (polarity > 0.2)
pos_df = df[df['Sentiment'] > 0.2]

# Generate word cloud for positive reviews
positive_text = " ".join(review for review in pos_df['Review'])

wordcloud = WordCloud(
    width=800, 
    height=800, 
    background_color='white', 
    stopwords=STOPWORDS, 
    min_font_size=10
).generate(positive_text)

# Plot the word cloud
plt.figure(figsize=(8, 8), facecolor=None)
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.tight_layout(pad=0)
plt.show()
