<?php
// Get the name entered by the user
$name = isset($_POST['name']) ? trim($_POST['name']) : "";

// Check if the name is empty
if (empty($name)) {
    echo "Stranger, please tell me your name!";
}
// Check if the name is one of the master names
elseif (in_array($name, ['Rohit', 'Virat', 'Dhoni', 'Ashwin', 'Harbhajan'])) {
    echo "Hello, master!";
}
// Otherwise, the server doesn't recognize the user
else {
    echo "$name, I don't know you!";
}
?>
