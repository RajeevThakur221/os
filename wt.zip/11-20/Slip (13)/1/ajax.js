$(document).ready(function() {
    // Attach an event listener to the name input field
    $('#name').on('input', function() {
        var name = $(this).val(); // Get the name entered by the user
        
        // Send an AJAX request to the server
        $.ajax({
            url: 'server.php',
            type: 'POST',
            data: { name: name },
            success: function(response) {
                $('#response').html(response); // Update the response div with the server's response
            },
            error: function() {
                $('#response').html("Error communicating with the server.");
            }
        });
    });
});
