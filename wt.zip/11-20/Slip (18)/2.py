import nltk
import re
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.probability import FreqDist
from wordcloud import WordCloud

# Download the necessary NLTK stopwords dataset
nltk.download('stopwords')
nltk.download('punkt')

# Define the text paragraph
text = """Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vel pharetra orci. 
Nulla varius, arcu vitae scelerisque tincidunt, elit justo interdum risus, quis tincidunt augue tortor nec urna. 
Morbi tristique ante et velit ullamcorper rhoncus. Morbi laoreet, magna est imperdiet quam, 
sit amet ultrices lectus justo id enim. Sed dictum suscipit commodo. 
Sed maximus consequat risus, nec pharetra nibh interdum quis. 
Etiam eget quam vel augue dictum dignissim sit amet nec elit. 
Nunc at sapien dolor. Nulla vitae iaculis lorem. Suspendisse potenti."""

# Remove special characters and convert to lowercase
text = re.sub(r'[^A-Za-z ]+', '', text).lower()

# Tokenize the paragraph to extract words and sentences
words = word_tokenize(text)
sentences = sent_tokenize(text)

# Remove stopwords from the extracted words
stop_words = set(stopwords.words('english'))
filtered_words = [word for word in words if word not in stop_words]

# Calculate word frequency distribution and plot the frequencies using matplotlib
fdist = FreqDist(filtered_words)

# Plot the frequency distribution
plt.figure(figsize=(10, 5))
fdist.plot(30, cumulative=False)
plt.title("Word Frequency Distribution")
plt.show()

# Generate and plot the WordCloud image
wordcloud = WordCloud(
    width=800, height=800,
    background_color='white',
    stopwords=stop_words,
    min_font_size=10
).generate(" ".join(filtered_words))

# Display the WordCloud
plt.figure(figsize=(8, 8), facecolor=None)
plt.imshow(wordcloud)
plt.axis("off")
plt.tight_layout(pad=0)
plt.title("Word Cloud Representation")
plt.show()
