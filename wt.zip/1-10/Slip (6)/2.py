import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# Create the dataset (Transaction Data)
TID = {
    1: ["bread", "milk"],
    2: ["bread", "diaper", "beer", "eggs"],
    3: ["milk", "diaper", "beer", "coke"],
    4: ["bread", "milk", "diaper", "beer"],
    5: ["bread", "milk", "diaper", "coke"]
}

# Convert dictionary to list of transactions
transactions = list(TID.values())

# Convert categorical values into a numerical format using TransactionEncoder
te = TransactionEncoder()
te_ary = te.fit_transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

# Apply the Apriori algorithm with different minimum support values
min_sup_values = [0.2, 0.4, 0.6]

for min_sup in min_sup_values:
    print(f"\n=== Minimum Support: {min_sup} ===")

    # Generate frequent itemsets
    frequent_itemsets = apriori(df, min_support=min_sup, use_colnames=True)
    print("\nFrequent Itemsets:")
    print(frequent_itemsets)

    # Generate association rules
    rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.0)
    print("\nAssociation Rules:")
    print(rules)
