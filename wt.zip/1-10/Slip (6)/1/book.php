<?php
// Load the XML file into a SimpleXML object
$xml = simplexml_load_file("book.xml") or die("Error: Cannot load XML file");

// Display the attributes and elements of the SimpleXML object
echo "<h2>Book Attributes:</h2>";
echo "ISBN: " . $xml['isbn'] . "<br>";
echo "Publisher: " . $xml['publisher'] . "<br><br>";

echo "<h2>Book Elements:</h2>";
echo "Title: " . $xml->title . "<br>";
echo "Author: " . $xml->author . "<br>";
echo "Description: " . $xml->description . "<br>";
?>

