<?php
// Start session
session_start();

// Set maximum login attempts
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 3;
}

// Check if login form has been submitted
if (isset($_POST['submit'])) {
    // Get username and password input from user
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Set correct username and password
    $correct_username = 'myusername';
    $correct_password = 'mypassword';

    // Check if entered username and password are correct
    if ($username == $correct_username && $password == $correct_password) {
        // Set session variable to mark user as logged in
        $_SESSION['loggedin'] = true;

        // Redirect user to welcome page
        header('Location: welcome.php');
        exit;
    } else {
        // Decrement login attempts
        $_SESSION['attempts']--;

        // Display error message if maximum login attempts exceeded
        if ($_SESSION['attempts'] <= 0) {
            echo "Maximum login attempts exceeded. Please try again later.";
        } else {
            // Display error message with remaining attempts
            echo "Invalid username or password. You have " . $_SESSION['attempts'] . " attempt(s) left.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login Form</h2>
    <form method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" name="submit" value="Log In">
    </form>
</body>
</html>
