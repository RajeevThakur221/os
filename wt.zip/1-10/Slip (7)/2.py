import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# Read the dataset
df = pd.read_csv("Market_Basket_Optimisation.csv", header=None)

# Drop null values
df.dropna(inplace=True)

# Convert categorical values to numerical using one-hot encoding
transactions = df.apply(lambda row: row.dropna().tolist(), axis=1).tolist()
te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df_encoded = pd.DataFrame(te_ary, columns=te.columns_)

# Generate frequent itemsets using Apriori algorithm
frequent_itemsets = apriori(df_encoded, min_support=0.01, use_colnames=True)

# Generate association rules from frequent itemsets
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.0)

# Display information
print("Original Dataset (First 5 rows):\n")
print(df.head())
print("\nFrequent Itemsets:\n")
print(frequent_itemsets)
print("\nAssociation Rules:\n")
print(rules)
