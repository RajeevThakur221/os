<?php
// Load the XML file
$xml = new DOMDocument();
$xml->load("Movie.xml");

// Get all the movie nodes
$movies = $xml->getElementsByTagName("MovieInfo");

// Loop through each movie node and print the movie title and actor name
foreach ($movies as $movie) {
    $title = $movie->getElementsByTagName("MovieTitle")->item(0)->textContent;
    $actor = $movie->getElementsByTagName("ActorName")->item(0)->textContent;
    $year = $movie->getElementsByTagName("ReleaseYear")->item(0)->textContent;
    
    echo "<strong>Movie Title:</strong> $title <br>";
    echo "<strong>Actor Name:</strong> $actor <br>";
    echo "<strong>Release Year:</strong> $year <br><br>";
}
?>
