import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# Load the dataset
df = pd.read_csv('market_basket.csv', header=None)

# Drop any rows with null values
df.dropna(inplace=True)

# Convert categorical values into a transaction list
transactions = df.apply(lambda x: x.dropna().tolist(), axis=1).tolist()

# Convert transaction list to numeric format using TransactionEncoder
te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df_encoded = pd.DataFrame(te_ary, columns=te.columns_)

# Generate frequent itemsets using the Apriori algorithm
frequent_itemsets = apriori(df_encoded, min_support=0.01, use_colnames=True)

# Generate association rules from frequent itemsets
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

# Display dataset information
print("Dataset Information:\n", df.info())

# Display frequent itemsets
print("\nFrequent Itemsets:\n", frequent_itemsets)

# Display association rules
print("\nAssociation Rules:\n", rules)
