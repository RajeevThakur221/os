<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Details</title>
</head>
<body>
    <h1>Employee Details</h1>
    <form method="POST" action="secondpage.php">
        <label for="eno">Employee No:</label>
        <input type="text" id="eno" name="eno" required><br><br>

        <label for="ename">Employee Name:</label>
        <input type="text" id="ename" name="ename" required><br><br>

        <label for="address">Address:</label>
        <textarea id="address" name="address" required></textarea><br><br>

        <input type="submit" value="Next">
    </form>
</body>
</html>
