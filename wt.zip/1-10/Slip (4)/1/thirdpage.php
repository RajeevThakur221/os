<?php
session_start();

// Store Earnings in session
if (isset($_POST['basic']) && isset($_POST['da']) && isset($_POST['hra'])) {
    $_SESSION['basic'] = $_POST['basic'];
    $_SESSION['da'] = $_POST['da'];
    $_SESSION['hra'] = $_POST['hra'];
}

// Calculate Total Earnings
$total = $_SESSION['basic'] + $_SESSION['da'] + $_SESSION['hra'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Information</title>
</head>
<body>
    <h1>Employee Information</h1>
    <p><strong>Employee No:</strong> <?php echo htmlspecialchars($_SESSION['eno']); ?></p>
    <p><strong>Employee Name:</strong> <?php echo htmlspecialchars($_SESSION['ename']); ?></p>
    <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($_SESSION['address'])); ?></p>
    <p><strong>Basic Salary:</strong> <?php echo htmlspecialchars($_SESSION['basic']); ?></p>
    <p><strong>DA:</strong> <?php echo htmlspecialchars($_SESSION['da']); ?></p>
    <p><strong>HRA:</strong> <?php echo htmlspecialchars($_SESSION['hra']); ?></p>
    <p><strong>Total Earnings:</strong> <?php echo $total; ?></p>
</body>
</html>
