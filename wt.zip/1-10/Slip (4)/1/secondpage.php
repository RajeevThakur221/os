<?php
session_start();

// Store Employee details in session
if (isset($_POST['eno']) && isset($_POST['ename']) && isset($_POST['address'])) {
    $_SESSION['eno'] = $_POST['eno'];
    $_SESSION['ename'] = $_POST['ename'];
    $_SESSION['address'] = $_POST['address'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Earnings</title>
</head>
<body>
    <h1>Earnings</h1>
    <form method="POST" action="thirdpage.php">
        <label for="basic">Basic Salary:</label>
        <input type="number" id="basic" name="basic" required><br><br>

        <label for="da">DA:</label>
        <input type="number" id="da" name="da" required><br><br>

        <label for="hra">HRA:</label>
        <input type="number" id="hra" name="hra" required><br><br>

        <input type="submit" value="Next">
    </form>
</body>
</html>
