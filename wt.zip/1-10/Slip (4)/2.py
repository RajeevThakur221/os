import pandas as pd
import random
from sklearn.linear_model import LinearRegression

# Create the dataset
fish_species = ['Tuna', 'Salmon', 'Trout', 'Bass', 'Sardine', 'Target_Weight']
weights = []

for _ in range(50):  # Generate data for 50 fish
    fish_weight = [random.randint(1, 20) for _ in range(5)]  # Random weights for 5 species
    fish_weight.append(random.randint(5, 50))  # Target weight (dependent variable)
    weights.append(fish_weight)

# Create DataFrame
df = pd.DataFrame(weights, columns=fish_species)

# Define independent (X) and dependent (Y) variables
X = df.iloc[:, :-1]  # All species weights as features
Y = df.iloc[:, -1]   # Target weight

# Create and train the Linear Regression model
model = LinearRegression()
model.fit(X, Y)

# Predict the weight of a new fish sample
new_fish = [[10, 12, 15, 7, 4]]  # Example input (weights for 5 species)
predicted_weight = model.predict(new_fish)

print("Predicted weight:", predicted_weight[0])
